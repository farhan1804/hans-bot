// menu fitur bot
const a = '```'
const help = (prefix, h2k, instagram, linkCuriga, name, pushname2, user, limitnya, uptime, jam, tanggal, groupName, chats, premi, groups, Simihh, Welcomee, Nsfww, BadWordd, AntiLinkk, AntiVirtexx, autostickernya, frhan, process, RAM, Ramadhan, Ucapan, premium) => { 
	return `
*Hai ${Ucapan}*

${a}Follow My Instagram${a}
${instagram}

${a}Powered By${a}
${linkCuriga}

*╭⍟───────────────────────⍟╮*
                    *ROAD TO RAMADHAN*
   ${a}${Ramadhan}${a}

*╰⍟───────────────────────⍟╯*

╭──❀「 *REGULATION ${name}* 」
┴
│
│✾ ${a}NAMA USER:${a} *${pushname2}*
│✾ ${a}CEK PREMIUM:${a} ${premi}
│✾ ${a}LIMIT:${a} *${limitnya}*
│
│✾ ${a}USER TERDAFTAR:${a} *${h2k(user.length)}*
│✾ ${a}USER PREMIUM:${a} *${premium.length} User*
│
│✾ ${a}TOTAL GROUP:${a} *${groups.length} Groups*
│✾ ${a}TOTAL CHAT:${a} *${chats.length} Chats*
│
│✾ ${a}NAMA GRUP:${a} *${groupName}*
│✾ ${a}MODE WELCOME:${a} *${Welcomee}*
│✾ ${a}MODE SIMI:${a} *${Simihh}*
│✾ ${a}MODE NSFW:${a} *${Nsfww}*
│✾ ${a}MODE ANTI BADWORD:${a} *${BadWordd}*
│✾ ${a}MODE ANTI LINK:${a} *${AntiLinkk}*
│✾ ${a}MODE ANTI VIRTEX:${a} *${AntiVirtexx}*
│✾ ${a}MODE AUTO STICKER:${a} *${autostickernya}*
│
┬
╰────────────────────────

╭─────❀「 *FEATURES MENU* 」
┴
│✾ *${prefix}mutualan*
├── ${a}Mencari teman chat${a}
│✾ *${prefix}report lapor bug*
├── ${a}Untuk Melaporkan Bug Ke Owner${a}
│✾ *${prefix}info*
├── ${a}Untuk Menampilkan Info Bot${a}
│✾ *${prefix}donasi*
├── ${a}Jika Berkenan Untuk Donasi${a}
│✾ *${prefix}owner*
├── ${a}Bot Mengirimkan Nomer Owner${a}
│✾ *${prefix}speed*
├── ${a}Testing Respon Bot${a}
│✾ *${prefix}daftar*
├── ${a}Untuk Mendaftar Yg Belom Terdaftar${a}
│✾ *${prefix}limit*
├── ${a}Untuk Cek Limit Anda${a}
│✾ *${prefix}blocklist*
├── ${a}Check Kontak Kontak Yg Diblock${a}
│✾ *${prefix}banlist*
├── ${a}Check Kontak Yg Dibanned${a}
│✾ *${prefix}premiumlist*
├── ${a}Menampilkan list user premium${a}
│✾ *${prefix}bahasa*
├── ${a}Untuk Fitur text to speech${a}
│✾ *${prefix}wame*
├── ${a}Create Link Nomer WA Anda${a}
│✾ *${prefix}listbadword*
├── ${a}mengirimkan list badword${a}
│✾ *${prefix}listonline*
├── ${a}list online group ${groupName}${a}
│✾ *${prefix}addsticker*
├── ${a}menambahkan stiker ke database${a}
│✾ *${prefix}getsticker*
├── ${a}mengirimkan stiker sesuai list${a}
│✾ *${prefix}stickerlist*
├── ${a}mengirimkan list stiker${a}
│✾ *${prefix}addvideo*
├── ${a}menambahkan video ke database${a}
│✾ *${prefix}video*
├── ${a}mengirimkan video sesuai list${a}
│✾ *${prefix}videolist*
├── ${a}mengirimkan list video${a}
│✾ *${prefix}image*
├── ${a}mengirimkan image sesuai list${a}
│✾ *${prefix}addImage*
├── ${a}mengirimkan image sesuai list${a}
│✾ *${prefix}imagelist*
├── ${a}mengirimkan list image${a}
│✾ *${prefix}addvn*
├── ${a}menambahkan audio ke database${a}
│✾ *${prefix}vn*
├── ${a}mengirimkan audio sesuai list${a}
│✾ *${prefix}vnlist*
├── ${a}mengirimkan audio image${a}
┬
╰────────────────────────

╭─────❀「 *SIMPLE MENU* 」
┴
│✾ *${prefix}menuothers*
│✾ *${prefix}menugroup*
│✾ *${prefix}menumaker*
│✾ *${prefix}menuowners*
│✾ *${prefix}menupremium*
│✾ *${prefix}menuinfo*
┬
╰────────────────────────

╭─────❀「 *TOP UP MENU* 」
┴
│✾ *${prefix}ff*
│✾ *${prefix}ml*
│✾ *${prefix}vilogff*
│✾ *${prefix}payment*
┬
╰────────────────────────

╭─────≽「 *ABOUT ${name}* 」
┴
│
│✾  ${a}JAM:${a} *${jam} WIB*
│✾  ${a}TANGGAL:${a} *${tanggal}*
│✾  ${a}AKTIF:${a} ${kyun(uptime)}
│✾  ${a}BROWSER:${a} *${frhan.browserDescription[1]}*
│✾  ${a}SERVER:${a} *${frhan.browserDescription[0]}*
│✾  ${a}VERSION:${a} *${frhan.browserDescription[2]}*
│✾  ${a}SPEED:${a} *${process.uptime()}*
│✾  ${a}DEVICE:${a} *${frhan.user.phone.device_manufacturer}*
│✾  ${a}DEVICE MODEL:${a} *${frhan.user.phone.device_model}*
│✾  ${a}DEVICE RAM:${a} *${RAM}*
│✾  ${a}WA VERSION:${a} *${frhan.user.phone.wa_version}*
│
┬
╰────────────────────────

╭────≽「 *SUPPORT ${name}* 」
┴
│➲ ${a}MANORIUS${a}
│➲ ${a}ACIL BOT${a}
│➲ ${a}WAN BOT${a}
│➲ ${a}RAKHA BOT${a}
│➲ ${a}DELIA AULIA${a}
│➲ ${a}KEVIN DAVID${a}
│➲ ${a}MY TEAM FXC7 BOT${a}
│➲ ${a}PENYEDIA REST API${a}
│➲ ${a}CONTENT CREATOR BOT WHATSAPP${a}
┬
╰──────≽ *Created © FXC7*
`
}

exports.help = help

const ffmenu = () => {
return `
┏━━━━━━━━━━━━━━━━━━━━━━━━━┓
┃    *────⊱ FREE FIRE VIA ID ⊰────*
┃➻ ${a}Process: 1 - 10 menit${a}
┃➻ ${a}Stock  : Unlimited${a}
┃➻ ${a}Need   : ID & Nick${a}
┣━━━━━━━━━━━━━━━━━━━━━━━━━┛
┃   *───⊱ NOMINAL DIAMONDS ⊰───*
┃ ${a}50   DM = Rp. 6.672${a}
┃ ${a}70   DM = Rp. 9.174${a}
┃ ${a}100  DM = Rp. 13.344${a}
┃ ${a}140  DM = Rp. 18.348${a}
┃ ${a}150  DM = Rp. 20.016${a}
┃ ${a}210  DM = Rp. 27.522${a}
┃ ${a}280  DM = Rp. 36.696${a}
┃ ${a}355  DM = Rp. 45.870${a}
┃ ${a}425  DM = Rp. 55.044${a}
┃ ${a}500  DM = Rp. 65.052${a}
┃ ${a}720  DM = Rp. 91.740${a}
┃ ${a}860  DM = Rp. 110.088${a}
┃ ${a}1000 DM = Rp. 128.436${a}
┃ ${a}1075 DM = Rp. 137.610${a}
┃ ${a}1440 DM = Rp. 183.480${a}
┃ ${a}2000 DM = Rp. 250.200${a}
┃ ${a}2180 DM = Rp. 278.000${a}
┃  *───⊱ MEMBERSHIP ⊰───*
┃ ${a}MM      = Rp. 27.800${a}
┃ ${a}MB      = Rp. 111.200${a}
┗━━━━━━━━━━━━━━━━━━━━━━━━━┛
`
}
exports.ffmenu = ffmenu

const mlmenu = () => {
return `
┏━━━━━━━━━━━━━━━━━━━━━━━━━┓
┃    *────⊱ MOBILE LEGENDS ⊰────*
┃➻ ${a}Process: 1 - 10 menit${a}
┃➻ ${a}Stock  : Unlimited${a}
┃➻ ${a}Need   : ID & Server${a}
┣━━━━━━━━━━━━━━━━━━━━━━━━━┛
┃   *───⊱ NOMINAL DIAMONDS ⊰───*
┃ ${a}86   DM = Rp. 16.800${a}
┃ ${a}172  DM = Rp. 33.600${a}
┃ ${a}257  DM = Rp. 50.400${a}
┃ ${a}344  DM = Rp. 67.200${a}
┃ ${a}429  DM = Rp. 84.000${a}
┃ ${a}514  DM = Rp. 100.800${a}
┃ ${a}706  DM = Rp. 134.400${a}
┃ ${a}878  DM = Rp. 168.000${a}
┃ ${a}1050 DM = Rp. 201.600${a}
┃ ${a}1412 DM = Rp. 268.800${a}
┃ ${a}2195 DM = Rp. 399.000${a}
┃ ${a}3688 DM = Rp. 663.600${a}
┃ ${a}5532 DM = Rp. 996.800${a}
┃  *───⊱ STARLIGHT ⊰───*
┃ ${a}SL/TL   = Rp. 110.860${a}
┃ ${a}STAR+   = Rp. 252.000${a}
┗━━━━━━━━━━━━━━━━━━━━━━━━━┛
`
}
exports.mlmenu = mlmenu
const vilogff = () => {
return `
┏━━━━━━━━━━━━━━━━━━━━━━━━━┓
┃ ───⊱ *FREE FIRE VIA LOGIN* ⊰───
┃➻ ${a}Process: 1 - 10 menit${a}
┃➻ ${a}Stock  : Unlimited${a}
┃➻ ${a}Need   : DATA AKUN${a}
┣━━━━━━━━━━━━━━━━━━━━━━━━━┛
┃  *───⊱ NOMINAL DIAMONDS ⊰───*
┃ ${a}100    DM = IDR 12.000${a}
┃ ${a}200    DM = IDR 24.000${a}
┃ ${a}310    DM = IDR 36.000${a}
┃ ${a}520    DM = IDR 60.000${a}
┃ ${a}830    DM = IDR 96.000${a}
┃ ${a}1060   DM = IDR 120.000${a}
┃ ${a}1370   DM = IDR 156.000${a}
┃ ${a}1580   DM = IDR 180.000${a}
┃ ${a}2180   DM = IDR 240.000${a}
┃ ${a}2700   DM = IDR 300.000${a}
┃ ${a}3240   DM = IDR 360.000${a}
┃ ${a}4360   DM = IDR 480.000${a}
┃ ${a}5600   DM = IDR 590.000${a}
┃ ${a}6660   DM = IDR 708.000${a}
┃ ${a}7780   DM = IDR 826.000${a}
┃ ${a}11200  DM = IDR 1.150.000${a}
┃  ───⊱ *MEMBERSHIP* ⊰───
┃ ${a}MM      = Rp. 24.000${a}
┃ ${a}MB      = Rp. 96.000${a}
┗━━━━━━━━━━━━━━━━━━━━━━━━━┛
*NOTE :*
${a}• Proses 1 - 10 menit ( Tergantung antrian )${a}
${a}• Harga sewaktu waktu bisa berubah.${a}
${a}• Wajib Kirim kode pemulihan apabila memakai 2Faktor ( Terutama Login GOOGLE )${a}

*ALASAN PROSES LAMA :*
${a}• Jumlah orderan banyak${a}
${a}• Jaringan admin${a}
`
}
exports.vilogff = vilogff

const payment = () => {
return `
┏━━━━━━━━━━━━━━━━━━━━━┓
┃    *────⊱ PAYMENT ⊰────*
┣━━━━━━━━━━━━━━━━━━━━━┛
┃ *────⊱* ${a}E WALLET${a} *⊰────*
┣━⊱ *GOPAY*
┣⊱ 085264383100
┣━⊱ *DANA*
┣⊱ 085264383100
┣━⊱ *QRIS*
┣⊱ _KHUSUS DANA | PP GRUP_
┗━━━━━━━━━━━━━━━━━━━━━━┛
`
}
exports.payment = payment

const menupremium = (prefix) => {
return `
╭────❀「 *PREMIUM ONLY* 」
│
│✾ *${prefix}spamcall 083xxxxxxxxx*
│✾ *${prefix}spamgmail contoh@gmail.com*
│✾ *${prefix}spamsms 6283xxxxxxxxx*
│✾ *${prefix}playmp3 menepi*
│✾ *${prefix}fb link video*
│✾ *${prefix}snack link snack video*
│✾ *${prefix}ytmp4 link yt*
│✾ *${prefix}ytmp3 link yt*
│✾ *${prefix}music judul*
│✾ *${prefix}getmusic ID Download*
│✾ *${prefix}video judul*
│✾ *${prefix}getvideo ID Download*
│✾ *${prefix}tiktok link video tiktok*
│✾ *${prefix}joox Monolog Pamungkas*
│✾ *${prefix}smule Link Video Smule*
╰────────────────────────
`
}
exports.menupremium = menupremium

const menuothers = (prefix) => {
return `
╭─────❀「 *MEDIA & DOWNLOADER* 」
│
│✾ *${prefix}tiktokstalk username*
│✾ *${prefix}igstalk frhnrzky.sh*
│✾ *${prefix}tiktoksearch dayana*
│✾ *${prefix}igvideo link valid*
│✾ *${prefix}igimage link valid*
│✾ *${prefix}igtv link valid*
│✾ *${prefix}instastory username*
│✾ *${prefix}ssweb url*
│✾ *${prefix}url2img Url*
│✾ *${prefix}tiktok*
│✾ *${prefix}fototiktok*
│✾ *${prefix}kbbi*
│✾ *${prefix}wait*
│
├─────❀「 *OTHERS MENU* 」
│
│✾ *${prefix}randomwpanime*
│✾ *${prefix}randomexo*
│✾ *${prefix}randombts*
│✾ *${prefix}blackpink*
│✾ *${prefix}anjing*
│✾ *${prefix}kucing*
│✾ *${prefix}testime*
│✾ *${prefix}quotes*
│✾ *${prefix}katabijak*
│✾ *${prefix}bucin*
│✾ *${prefix}bacotandilan*
│✾ *${prefix}pantun*
│✾ *${prefix}hekerbucin*
│✾ *${prefix}katailham*
│
├─────❀「 *QUIZ MENU* 」
│
│✾ *${prefix}tebakgambar*
│✾ *${prefix}caklontong*
│✾ *${prefix}family100*
│✾ *${prefix}tebakkata*
│
├─────❀「 *FUN MENU* 」
│
│✾ *${prefix}truth*
│✾ *${prefix}dare*
│✾ *${prefix}readmore*
│✾ *${prefix}puisiimg*
│✾ *${prefix}asupan*
│✾ *${prefix}meme*
│✾ *${prefix}memeindo*
│✾ *${prefix}darkjokes*
│✾ *${prefix}kalkulator 13*12*
│✾ *${prefix}fakedeface link|Hacked By|awokwokwok*
│
├─────❀「 *ISLAMIC MENU* 」
│
│✾ *${prefix}jadwalsholat Banyuwangi*
│✾ *${prefix}quran*
│✾ *${prefix}listsurah*
│✾ *${prefix}quransurah 1*
│✾ *${prefix}asmaulhusna*
│
├─────❀「 *PRIMBON MENU* 」
│
│✾ *${prefix}apakah aku ganteng?*
│✾ *${prefix}kapankah aku menikah?*
│✾ *${prefix}bisakah aku memilikimu?*
│✾ *${prefix}rate reply something*
│✾ *${prefix}watak Farhan*
│✾ *${prefix}hobby Farhan*
│✾ *${prefix}gantengcek Farhan*
│✾ *${prefix}cantikcek Iriene*
│✾ *${prefix}persengay Topan*
│✾ *${prefix}pbucin Farhan*
│✾ *${prefix}mimpi Ular*
│✾ *${prefix}artinama Farhan*
│✾ *${prefix}pasangan Farhan/Iriene*
│✾ *${prefix}tanggaljadian 13/02/2021*
│✾ *${prefix}tanggallahir 01/05/2003*
│✾ *${prefix}zodiak taurus*
╰────────────────────────
`
}
exports.menuothers = menuothers

const menuinfo = (prefix) => {
return `
╭─────❀「 *INFORMATION MENU* 」
│
│✾ *${prefix}fakta*
│✾ *${prefix}infogempa*
│✾ *${prefix}jarak Banyuwangi/Surabaya*
│✾ *${prefix}translate en/Apa kabar?*
│✾ *${prefix}bpfont Farhan*
│✾ *${prefix}jadwaltv antv*
│✾ *${prefix}jadwaltvnow*
│✾ *${prefix}lirik melukis senja*
│✾ *${prefix}chord Melukis senja*
│✾ *${prefix}wiki Adolf Hitler*
│✾ *${prefix}brainly pertanyaan*
│✾ *${prefix}resepmasakan bakwan*
│✾ *${prefix}map Banyuwangi*
│✾ *${prefix}film Fast and Farious*
│✾ *${prefix}pinterest gambar kucing*
│✾ *${prefix}infocuaca Banyuwangi*
│✾ *${prefix}jamdunia Banyuwangi*
│✾ *${prefix}infoalamat jalan Banyuwangi*
│✾ *${prefix}playstore WhatsApp*
│✾ *${prefix}moddroid lightroom*
│✾ *${prefix}happymod lightroom*
│
├────❀「 *STORY & SCRAPPER MENU* 」
│
│✾ *${prefix}hororstory*
│✾ *${prefix}cersex*
│✾ *${prefix}cerpen*
│✾ *${prefix}wattpad tere liye*
│✾ *${prefix}bacawattpad link wattpad*
│✾ *${prefix}ytsearch judul*
│✾ *${prefix}drakor vagabond*
│✾ *${prefix}randomkpop*
│✾ *${prefix}randombokep*
│✾ *${prefix}pornhub stepMoms*
│✾ *${prefix}xvideos japan*
│✾ *${prefix}xnxx japan*
│✾ *${prefix}nekopoi oni chichi*
│
├───❀「 *ENCRYPT & DECRYPT MENU* 」
│
│✾ *${prefix}encode64 string*
│✾ *${prefix}decode64 encrypt*
│✾ *${prefix}hexaencode string*
│✾ *${prefix}hexadecode encrypt*
│✾ *${prefix}encbinary string*
│✾ *${prefix}decbinary encrypt*
│✾ *${prefix}encoctal string*
│✾ *${prefix}decoctal encrypt*
│✾ *${prefix}dorking dork*
│✾ *${prefix}whois Domain*
│✾ *${prefix}hostsearch Domain*
│✾ *${prefix}dnslookup IP/Domain*
│✾ *${prefix}geoip IP*
│✾ *${prefix}nping IP*
│✾ *${prefix}pastebin teks*
│✾ *${prefix}tinyurl link*
│✾ *${prefix}bitly link*
│✾ *${prefix}hashidentifier Encrypt Hash*
╰────────────────────────
`
}
exports.menuinfo = menuinfo

const menugrup = (prefix) => {
return `
╭───❀「 *AKTIFKAN JIKA DIPERLUKAN* 」
│
│✾ *${prefix}antilink On/Off*
│✾ *${prefix}welcome On/Off*
│✾ *${prefix}grup buka/tutup*
│✾ *${prefix}nsfw On/Off*
│✾ *${prefix}simih On/Off*
│✾ *${prefix}antivirtex on/off*
│✾ *${prefix}badword on/off*
│✾ *${prefix}autostiker on/off*
│
├───❀「 *MENU GROUP ONLY* 」
│
│✾ *${prefix}fitnah @mentioned/isi/balasan*
│✾ *${prefix}ownergrup*
│✾ *${prefix}listonline*
│✾ *${prefix}setpp*
│✾ *${prefix}infogrup*
│✾ *${prefix}add 628xxxxxxxxxx*
│✾ *${prefix}kick @mentioned*
│✾ *${prefix}kicktime @mentioned*
│✾ *${prefix}promote @mentioned*
│✾ *${prefix}demote @mentioned*
│✾ *${prefix}setname*
│✾ *${prefix}setdesc*
│✾ *${prefix}linkgrup*
│✾ *${prefix}tagme*
│✾ *${prefix}wame*
│✾ *${prefix}afk Reason*
│✾ *${prefix}hidetag*
│✾ *${prefix}tagall*
│✾ *${prefix}mentionall*
│✾ *${prefix}adminlist*
│
├───❀「 *NSFW ONLY GROUP* 」
│
│✾ *${prefix}neonime naruto*
│✾ *${prefix}animecry*
│✾ *${prefix}animekiss*
│✾ *${prefix}nsfwloli*
│✾ *${prefix}nsfwpussy*
│✾ *${prefix}nsfwclasic*
│✾ *${prefix}nsfwyuri*
│✾ *${prefix}nsfwlewd*
│✾ *${prefix}nsfwsolo*
│✾ *${prefix}nsfweron*
│✾ *${prefix}nsfwparadise*
│✾ *${prefix}nsfwbigtt*
│✾ *${prefix}nsfwecchi*
│✾ *${prefix}nsfwcum*
│✾ *${prefix}nsfwblowjob*
│✾ *${prefix}nsfwneko*
│✾ *${prefix}nsfwtrap*
│✾ *${prefix}hentai*
╰────────────────────────
`
}
exports.menugrup = menugrup

const menuowner = (prefix) => {
return `
╭───❀「 *OWNER ONLY* 」
│
│✾ *${prefix}addstatus*
│✾ *${prefix}addbadword*
│✾ *${prefix}dellbadword*
│✾ *${prefix}zalgo*
│✾ *${prefix}vapor*
│✾ *${prefix}pitch*
│✾ *${prefix}addpremium mentioned*
│✾ *${prefix}dellpremium mentioned*
│✾ *${prefix}setmemlimit*
│✾ *${prefix}setlimit*
│✾ *${prefix}setreply*
│✾ *${prefix}setprefix*
│✾ *${prefix}setnamebot*
│✾ *${prefix}setppbot*
│✾ *${prefix}bc*
│✾ *${prefix}bcgc*
│✾ *${prefix}ban*
│✾ *${prefix}unban*
│✾ *${prefix}block*
│✾ *${prefix}unblock*
│✾ *${prefix}clearall*
│✾ *${prefix}delete*
│✾ *${prefix}clone*
│✾ *${prefix}getses*
│✾ *${prefix}leave*
╰────────────────────────
`
}
exports.menuowner = menuowner


// penghitung aktif bot
function kyun(seconds){
  function pad(s){
    return (s < 10 ? '0' : '') + s;
  }
  var hours = Math.floor(seconds / (60*60));
  var minutes = Math.floor(seconds % (60*60) / 60);
  var seconds = Math.floor(seconds % 60);
  return `*${pad(hours)} Jam ${pad(minutes)} Menit ${pad(seconds)} Detik*`
}

// info bot 
const bottt = (prefix) => {
return `
${a}Untuk Sekarang Bot Hanya Bisa Digunakan Di Group Karna,${a} \n*Kalian Yang Menggunakan Bot Terlalu Spam*

*NOTE:*
Jika Bot Ini Ada Di Grup Anda Admin Grup Suruh Aktifkan Bot Dengan Cara ${prefix}bott aktif

*Adapun Daftar Menu Yang Di Public Sama Owner Dan Bisa Kalian Gunakan Tanpa Di Group*

- ${prefix}brainly
- ${prefix}kalkulator
- ${prefix}ytsearch
- ${prefix}moddroid
- ${prefix}happymod
- ${prefix}playstore
- ${prefix}tanggaljadian
- ${prefix}stiker
- ${prefix}resepmasakan
- ${prefix}film
- ${prefix}infocuaca
- ${prefix}infogempa
- ${prefix}tahta
- ${prefix}igstalk
- ${prefix}tiktokstalk
- ${prefix}instastory
- ${prefix}translate
- ${prefix}quran
- ${prefix}tafsirquran
- ${prefix}lirik
- ${prefix}chord
- ${prefix}nulis
- ${prefix}puisiimg
- ${prefix}randomkpop
- ${prefix}quotes
- ${prefix}bucin
- ${prefix}artinama
- ${prefix}wattpad
- ${prefix}jarak
- ${prefix}infoalamat
- ${prefix}mimpi
- ${prefix}bacotandilan
- ${prefix}instavid
- ${prefix}instaimg

*Apa Yang Terbaru??*

~ random gambar KPOP ✓
~ random gambar EXO ✓
~ Fitur Anti virtex ✓
~ Fitur Anti Link ✓
~ Bacotan Dilan ✓
~ wattpad searching ✓
~ puisi dalam bentuk gambar ✓
~ Mencari resep masakan ✓
~ text to picture (bisa request warna) ✓
~ Tiktok scrapper ✓
~ instagram image downloader ✓ => command: ${prefix}instaimg link url
~ instagram video downloader ✓ => command: ${prefix}instavid link url

~ Resep Masakan ✓ => comand: ${prefix}resepmasakan rawon [ contoh]

~ Anti Virtex on/off ✓ command: ${prefix}antivirtex on
- *Gunakan Apabila Ada Yg Ngirim Virtex*

~ Anti Virtex ✓ => command: ${prefix}antivirtexx
- *Bot Akan Mengirimkan Teks Biar Member Tidak Mengalami Lag*

~ Xnxx scrapper ✓

`
}
exports.bottt = bottt
// donasi menu

const donasi = (name) => { 
	return `       
╭─≽「 *DONASI AGAR BOT TETAP ONLINE* 」
┴
│
├── *DANA/GOPAY* 085264383100
│
┬
╰─────≽「 *BY ${name}* 」

Untuk Kelangsungan Hidup Bot Karna Kuota Mahal:'
`
}
exports.donasi = donasi

const listsurah = () => {
return `
1. Al-Fatihah الفاتحة
2. Al-Baqarah البقرة
3. Ali ‘Imran آل عمران
4. An-Nisa’ النّساء
5. Al-Ma’idah المآئدة
6. Al-An’am الانعام
7. Al-A’raf الأعراف
8. Al-Anfal الأنفال
9. At-Taubah التوبة
10. Yunus ينوس
11. Hud هود
12. Yusuf يسوف
13. Ar-Ra’d الرّعد
14. Ibrahim إبراهيم
15. Al-Hijr الحجر
16. An-Nahl النّحل
17. Al-Isra’ بني إسرائيل
18. Al-Kahf الكهف
19. Maryam مريم
20. Ta Ha طه
21. Al-Anbiya الأنبياء
22. Al-Hajj الحجّ
23. Al-Mu’minun المؤمنون
24. An-Nur النّور
25. Al-Furqan الفرقان
26. Asy-Syu’ara’ الشّعراء
27. An-Naml النّمل
28. Al-Qasas القصص
29. Al-‘Ankabut العنكبوت
30. Ar-Rum الرّوم
31. Luqman لقمان
32. As-Sajdah السّجدة
33. Al-Ahzab الْأحزاب
34. Saba’ سبا
35. Fatir فاطر
36. Ya Sin يس
37. As-Saffat الصّافات
38. Sad ص
39. Az-Zumar الزّمر
40. Al-Mu’min المؤمن
41. Fussilat فصّلت
42. Asy-Syura الشّورى
43. Az-Zukhruf الزّخرف
44. Ad-Dukhan الدّخان
45. Al-Jasiyah الجاثية
46. Al-Ahqaf الَأحقاف
47. Muhammad محمّد
48. Al-Fath الفتح
49. Al-Hujurat الحجرات
50. Qaf ق
51. Az-Zariyat الذّاريات
52. At-Tur الطّور
53. An-Najm النّجْم
54. Al-Qamar القمر
55. Ar-Rahman الرّحْمن
56. Al-Waqi’ah الواقعه
57. Al-Hadid الحديد
58. Al-Mujadilah المجادلة
59. Al-Hasyr الحشْر
60. Al-Mumtahanah الممتحنة
61. As-Saff الصّفّ
62. Al-Jumu’ah الجمعة
63. Al-Munafiqun المنافقون
64. At-Tagabun التّغابن
65. At-Talaq الطّلاق
66. At-Tahrim التّحريم
67. Al-Mulk الملك
68. Al-Qalam القلم
69. Al-Haqqah الحآقّة
70. Al-Ma’arij المعارج
71. Nuh نوح
72. Al-Jinn الجنّ
73. Al-Muzzammil المزمّل
74. Al-Muddassir المدشّر
75. Al-Qiyamah القيمة
76. Al-Insan الْاٍنسان
77. Al-Mursalat المرسلات
78. An-Naba’ النّبا
79. An-Nazi’at النّازعات
80. ‘Abasa عبس
81. At-Takwir التّكوير
82. Al-Infitar الانفطار
83. Al-Tatfif المطفّفين
84. Al-Insyiqaq الانشقاق
85. Al-Buruj البروج
86. At-Tariq الطّارق
87. Al-A’la الْأعلى
88. Al-Gasyiyah الغاشية
89. Al-Fajr الفجر
90. Al-Balad البلد
91. Asy-Syams الشّمس
92. Al-Lail الّيل
93. Ad-Duha الضحى
94. Al-Insyirah الانشراح
95. At-Tin التِّينِ
96. Al-‘Alaq العَلَق
97. Al-Qadr الْقَدْرِ
98. Al-Bayyinah الْبَيِّنَةُ
99. Az-Zalzalah الزلزلة
100. Al-‘Adiyat العاديات
101. Al-Qari’ah القارعة
102. At-Takasur التكاثر
103. Al-‘Asr العصر
104. Al-Humazah الهُمَزة
105. Al-Fil الْفِيلِ
106. Quraisy قُرَيْشٍ
107. Al-Ma’un الْمَاعُونَ
108. Al-Kausar الكوثر
109. Al-Kafirun الْكَافِرُونَ
110. An-Nasr النصر
111. Al-Lahab المسد
112. Al-Ikhlas الإخلاص
113. Al-Falaq الْفَلَقِ
114. An-Nas نَاس
ِ`
}
exports.listsurah = listsurah

// bahasa list
const bahasa = (prefix) => {
return `
List Bahasa Untuk Command *${prefix}tts*

  af: Afrikaans
  sq: Albanian
  ar: Arabic
  hy: Armenian
  ca: Catalan
  zh: Chinese
  zh-cn: Chinese (Mandarin/China)
  zh-tw: Chinese (Mandarin/Taiwan)
  zh-yue: Chinese (Cantonese)
  hr: Croatian
  cs: Czech
  da: Danish
  nl: Dutch
  en: English
  en-au: English (Australia)
  en-uk: English (United Kingdom)
  en-us: English (United States)
  eo: Esperanto
  fi: Finnish
  fr: French
  de: German
  el: Greek
  ht: Haitian Creole
  hi: Hindi
  hu: Hungarian
  is: Icelandic
  id: Indonesian
  it: Italian
  ja: Japanese
  ko: Korean
  la: Latin
  lv: Latvian
  mk: Macedonian
  no: Norwegian
  pl: Polish
  pt: Portuguese
  pt-br: Portuguese (Brazil)
  ro: Romanian
  ru: Russian
  sr: Serbian
  sk: Slovak
  es: Spanish
  es-es: Spanish (Spain)
  es-us: Spanish (United States)
  sw: Swahili
  sv: Swedish
  ta: Tamil
  th: Thai
  tr: Turkish
  vi: Vietnamese
  cy: Welsh
`
}
exports.bahasa = bahasa

// Limit
const limitcount = (limitCounts) => {
        return`
Limit Kamu: ${limitCounts}
`
}
exports.limitcount = limitcount