[
{
    "result": {
        "Created": "FarhanXCode7",
        "soal": "Apa yang menarik dari film india?",
        "jawaban": "Tarian\nLagu\nCerita\nPakian"
    }
},
{
    "result": {
        "Created": "FarhanXCode7",
        "soal": "apa yang membuat pelayan di tempat fotokopi lambat?",
        "jawaban": "mesin rusak / rusak\nantri\nmati lampu\nkurang orang / kekurangan karyawan\nkertas habis\nmesin sedikit"
    }
},
{
    "result": {
        "Created": "FarhanXCode7",
        "soal": "Jenis-jenis cewek yang didemenin para cowok?",
        "jawaban": "Cantik\nSeksi\nManis\nManja"
    }
},
{
    "result": {
        "Created": "FarhanXCode7",
        "soal": "Sampah apa yang sering ditemukan dijalan?",
        "jawaban": "Kertas\nPlastik\nDaun\nPuntun\nRokok"
    }
},
{
    "result": {
        "Created": "FarhanXCode7",
        "soal": "apa yang dilakukan orang kalau kecapean?",
        "jawaban": "tidur\nmakan\nminum\nistirahat\nspa\nmandi "
    }
},
{
    "result": {
        "Created": "FarhanXCode7",
        "soal": "benda apa didalam rumah yang berwarna putih?",
        "jawaban": "lantai\ntembok\nlampu\nkulkas\nplastik\ntoples\nsofa / sofa putih"
    }
},
{
    "result": {
        "Created": "FarhanXCode7",
        "soal": "sebutkan sesuatu yang memiliki tali?",
        "jawaban": "sepatu\npakaian dalam\ntas\ncelana\npulpen"
    }
},
{
    "result": {
        "Created": "FarhanXCode7",
        "soal": "apa penyebab pinggang menjadi terkilir?",
        "jawaban": "angkat beban berat\nolahraga\njatuh\nsalah duduk "
    }
},
{
    "result": {
        "Created": "FarhanXCode7",
        "soal": "bagian/part dari komputer umum?",
        "jawaban": "ram\ncpu\nmouse\nkeyboard\nmonitor\nprinter\nscanner"
    }
},
{
    "result": {
        "Created": "FarhanXCode7",
        "soal": "suara yang ditakuti anak2?",
        "jawaban": "anjing\nhantu\npetir\nharimau"
    }
},
{
    "result": {
        "Created": "FarhanXCode7",
        "soal": "Perasaan apa yang ada bila mau kencan pertama?",
        "jawaban": "\nSenang\nGrogi\nGembira\nDag dig dug"
    }
},
{
    "result": {
        "Created": "FarhanXCode7",
        "soal": "selain kacang hijau, sebutkan ragam isi bakpau ?",
        "jawaban": "kacang hitam\ncoklat / cokelat\ndaging\nkentang "
    }
},
{
    "result": {
        "Created": "FarhanXCode7",
        "soal": "sebutkan sesuatu yang sekali pakai langsung buang?",
        "jawaban": "pembalut\ntisu\npopok bayi / popok\nkorek api / korek\nteh celup\nkondom"
    }
},
{
    "result": {
        "Created": "FarhanXCode7",
        "soal": "apa yang biasa dijadikan kado ulang tahun anak kecil?",
        "jawaban": "boneka\nsepeda\nkue\nbaju\ncelana\nmainan "
    }
},
{
    "result": {
        "Created": "FarhanXCode7",
        "soal": "sebutkan sesuatu yang kamu beli dari uang jajan sendiri?",
        "jawaban": "makanan\nmainan\nminuman\nalat tulis "
    }
},
{
    "result": {
        "Created": "FarhanXCode7",
        "soal": "bagian/part dari komputer umum?",
        "jawaban": "ram\ncpu\nmouse\nkeyboard\nmonitor\nprinter\nscanner"
    }
},
{
    "result": {
        "Created": "FarhanXCode7",
        "soal": "alasan apa yang orang katakan untuk menyudahi pembicaran di telepon?",
        "jawaban": "baterai habis\nmau ke toilet\npulsa habis\nsibuk\ntelepon masuk\nmau istirahat\nada tamu "
    }
},
{
    "result": {
        "Created": "FarhanXCode7",
        "soal": "gaya/ model berenang?",
        "jawaban": "punggung\ndada\nkupu-kupu\nkatak\nbebas "
    }
},
{
    "result": {
        "Created": "FarhanXCode7",
        "soal": "Bekal makan anak sekolah?",
        "jawaban": "Mie\nNasi goreng\nRoti\nNasi uduk"
    }
},
{
    "result": {
        "Created": "FarhanXCode7",
        "soal": "sebutkan warna-warna bunga mawar?",
        "jawaban": "merah\nputih\nkuning\njingga\norange\nmaroon\nmerah muda\nungu "
    }
},
{
    "result": {
        "Created": "FarhanXCode7",
        "soal": "apa yang tidak perlu dimiliki orang yang botak?",
        "jawaban": "sisir\nsampo / shampo\ngel / minyak rambut\npengering rambut "
    }
},
{
    "result": {
        "Created": "FarhanXCode7",
        "soal": "hal yang menakutkan bagi anak-anak?",
        "jawaban": "petir\nhantu\ngelap\norang marah / marah\nmimpi buruk / mimpi\npolisi"
    }
},
{
    "result": {
        "Created": "FarhanXCode7",
        "soal": "Apa yang menyebabkan suara serak?",
        "jawaban": "Teriak\nBatuk\nNangis\nNgedem"
    }
},
{
    "result": {
        "Created": "FarhanXCode7",
        "soal": "apa reaksi kamu jika mainan kamu tiba-tiba hidup?",
        "jawaban": "main bersama\ntakut\nsenang\nkaget\nbuang\nkasih tahu teman"
    }
},
{
    "result": {
        "Created": "FarhanXCode7",
        "soal": "apa penyebab pinggang menjadi terkilir?",
        "jawaban": "angkat beban berat\nolahraga\njatuh\nsalah duduk "
    }
},
{
    "result": {
        "Created": "FarhanXCode7",
        "soal": "apa yg biasanya sering lupa dibawa ?",
        "jawaban": "uang\ndompet\nhandphone\nkunci\nkacamata\nrokok\nstnk\nkorek"
    }
},
{
    "result": {
        "Created": "FarhanXCode7",
        "soal": "hal yang menakutkan bagi anak-anak?",
        "jawaban": "petir\nhantu\ngelap\norang marah / marah\nmimpi buruk / mimpi\npolisi"
    }
},
{
    "result": {
        "Created": "FarhanXCode7",
        "soal": "Jenis-jenis cewek yang didemenin para cowok?",
        "jawaban": "Cantik\nSeksi\nManis\nManja"
    }
},
{
    "result": {
        "Created": "FarhanXCode7",
        "soal": "Sifat yang dimiliki anak-anak",
        "jawaban": "Manja\nCengeng\nNakal\nPemalu"
    }
},
{
    "result": {
        "Created": "FarhanXCode7",
        "soal": "Apa yang dilakukan jika tersesat dihutan",
        "jawaban": "Menangis\nTeriak\nBerdoa\nDileme"
    }
},
{
    "result": {
        "Created": "FarhanXCode7",
        "soal": "kota di usa?",
        "jawaban": "new york\nlos angeles\norlando\nlas vegas\ntexas\nseattle\nboston "
    }
},
{
    "result": {
        "Created": "FarhanXCode7",
        "soal": "apa yang identik dengan bajaj?",
        "jawaban": "berisik / ribut\nroda tiga\noranye\nasap / polusi\nbergetar / getar\njakarta"
    }
},
{
    "result": {
        "Created": "FarhanXCode7",
        "soal": "ditoko apa orang lebih sering  melihat-lihat daripada membeli?",
        "jawaban": "baju\nperhiasan / emas\nkendaraan\nbuku\nsepatu\nelektronik "
    }
},
{
    "result": {
        "Created": "FarhanXCode7",
        "soal": "hewan tak berkaki?",
        "jawaban": "ular\ncacing\nbelut\nlintah\nsiput "
    }
},
{
    "result": {
        "Created": "FarhanXCode7",
        "soal": "Sifat yang dimiliki anak-anak",
        "jawaban": "Manja\nCengeng\nNakal\nPemalu"
    }
}
]